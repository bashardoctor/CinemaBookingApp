package com.hct.projects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaBookingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinemaBookingAppApplication.class, args);
	}

}
